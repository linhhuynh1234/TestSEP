﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class CourseController : Controller
    {
        public API api = new API();
        SepEntities db = new SepEntities();
        // GET: Student
        public ActionResult Index(string id)
        {
            string ma = Session["MaGV"].ToString();
            //  string ID = Session["ID"].ToString();
            var model = db.KhoaHocs.Where(x => x.MaMH == id && x.Ma==ma);
            // var bh = db.BuoiHocs.Where(x => x.MaKH == id);
            //ViewBag.Lesson = bh;
            return View(model);
        }

        public ActionResult ListStudent(string id)
        {
            //  int ID = int.Parse(id);
            var model = db.ThamDus.Where(x => x.MaKH == id);
            if (model.Count() == 0)
            {
                var data = api.GetMember(id);
                foreach (var item in data)
                {
                    SinhVien nStudent = new SinhVien();
                    nStudent.MSSV = item.id;
                    nStudent.Birthday = Convert.ToDateTime(item.birthday);
                    nStudent.FullName = item.fullname;
                    nStudent.LastName = item.lastname;
                    nStudent.FirstName = item.firstname;
                    db.SinhViens.Add(nStudent);

                    ThamDu nThamDu = new ThamDu();
                    nThamDu.MSSV = item.id;
                    nThamDu.MaKH = id;
                    db.ThamDus.Add(nThamDu);

                    db.SaveChanges();
                }
                model = db.ThamDus.Where(x => x.MaKH == id);
            }

            ViewBag.ID = id;
            return View(model);
        }

        public ActionResult ListBuoi(string id)
        {
            var model = db.BuoiHocs.Where(x => x.MaKH == id);
            return View(model);
        }

        public ActionResult ListDiemDanh(string id)
        {
            int ID = int.Parse(id);
            var model = db.DiemDanhs.Where(x => x.ID_BuoiHoc == ID);
            var makh = db.BuoiHocs.FirstOrDefault(x => x.ID_BH == ID).MaKH;
            ViewBag.BuoiHoc = new SelectList(db.BuoiHocs.Where(x => x.MaKH == makh), "ID_BH", "Buoi_thu");
           
            return View(model);
        }

        public ActionResult Change(string id)
        {
            var ID = int.Parse(id);
            var ID_Buoi = db.DiemDanhs.FirstOrDefault(x => x.ID == ID);
            if (ID_Buoi.status == true)
            {
                ID_Buoi.status = false;
            }
            else
            {
                ID_Buoi.status = true;
            }
            db.SaveChanges();
            return RedirectToAction("ListDiemDanh", new { id = ID_Buoi.ID_BuoiHoc });
        }
        [HttpPost]
        public ActionResult edit(string Buoithu)
        {
            return RedirectToAction("ListDiemDanh", new { id = Buoithu });
        }


        public ActionResult DiemDanhthucong(string id) // id truyen ma khoa hoc dang chon
        {

            BuoiHoc bhoc = new BuoiHoc();
            bhoc.NgayHoc = Convert.ToDateTime(DateTime.Now);
            bhoc.Buoi_thu = db.BuoiHocs.Where(x => x.MaKH == id).Count() +1;
            int idbh = db.BuoiHocs.Where(x => x.MaKH == id).Count() + 1; ;
            bhoc.MaKH = id;
            db.BuoiHocs.Add(bhoc);
            db.SaveChanges();
          
            foreach (var dd in db.ThamDus.Where(x => x.MaKH == id)) {
                DiemDanh ddanh = new DiemDanh();
                ddanh.MSSV = db.ThamDus.Where(x => x.MaKH == id).ToString();
                ddanh.status = false;
                ddanh.ID_BuoiHoc = idbh;
                db.DiemDanhs.Add(ddanh);
                db.SaveChanges();
            }


            return RedirectToAction("Index", new { id = "SP"});
        }

    }
}